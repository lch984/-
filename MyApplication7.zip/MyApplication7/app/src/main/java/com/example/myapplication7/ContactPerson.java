package com.example.myapplication7;

public class ContactPerson {
    private String ContactName;
    private String ContactNumber;

    public ContactPerson(){

    }

    public ContactPerson(String cName,String cNumber){
        this.ContactName = cName;
        this.ContactNumber = cNumber;
    }

    public String getContactName() {
        return ContactName;
    }
    public void setContactName(String contactName) {
        ContactName = contactName;
    }

    public String getContactNumber() {
        return ContactNumber;
    }
    public void setContactNumber(String contactNumber) {
        ContactNumber = contactNumber;
    }
}
