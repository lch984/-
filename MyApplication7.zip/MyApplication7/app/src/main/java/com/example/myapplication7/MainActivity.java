package com.example.myapplication7;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ArrayList<ContactPerson> cpList = new ArrayList<>();
    public final static String NUM = ContactsContract.CommonDataKinds.Phone.NUMBER;
    public final static String NAME = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //判断用户是否已经授权给我们了 如果没有，调用下面方法向用户申请授权，之后系统就会弹出一个权限申请的对话框
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    MainActivity.this,new String[]{Manifest.permission.READ_CONTACTS},1);
        } else {
            readContacts();
        }

        ContactAdapter MyAdapter = new ContactAdapter(MainActivity.this,R.layout.list_layout,cpList);
        ListView listview = (ListView)findViewById(R.id.list_view);
        listview.setAdapter(MyAdapter);
    }

    private void readContacts(){
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, new String[]{NUM,NAME}, null, null, null);
            while (cursor.moveToNext()) {
                ContactPerson cp = new ContactPerson();
                String ContactName = cursor.getString(cursor.getColumnIndex(NAME));
                String ContactNumber = cursor.getString(cursor.getColumnIndex(NUM));
                Toast.makeText(MainActivity.this, ContactName+" "+ContactNumber,
                        Toast.LENGTH_SHORT).show();
                cp.setContactName(ContactName);
                cp.setContactNumber(ContactNumber);
                cpList.add(cp);
            }
        }catch(Exception e) {
            e.printStackTrace();
        }finally {
            if(cursor!=null){
                cursor.close();
            }
        }
    }

    //回调方法，无论哪种结果，最终都会回调该方法，之后在判断用户是否授权，
    // 用户同意则调用readContacts（）方法，失败则会弹窗提示失败
    @Override
    public void onRequestPermissionsResult(int requestCode,String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 1:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    readContacts();
                } else {
                    Toast.makeText(this, "获取联系人权限失败", Toast.LENGTH_SHORT).show();
                }
                break;
            default:
        }
    }
}

class ContactAdapter<ContactPerson> extends ArrayAdapter<ContactPerson>{

    private int resourceId;
    public ContactAdapter( Context context, int resource,  List<ContactPerson> objects) {
        super(context, resource, objects);
        resourceId = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        com.example.myapplication7.ContactPerson cp = (com.example.myapplication7.ContactPerson)getItem(position);
        View view;
        ViewHolder viewHolder;
        if(convertView == null){
            view = LayoutInflater.from(getContext()).inflate(resourceId,null);
            viewHolder = new ViewHolder();
            viewHolder.ContactName = (TextView)view.findViewById(R.id.ContactName);
            viewHolder.ContactNumber = (TextView)view.findViewById(R.id.ContactNumber);
            view.setTag(viewHolder);
        }else{
            view = convertView;
            viewHolder = (ViewHolder) view.getTag();
        }

        viewHolder.ContactName.setText(cp.getContactName());
        viewHolder.ContactNumber.setText(cp.getContactNumber());
        return view;
    }
}

class ViewHolder{
    TextView ContactName;
    TextView ContactNumber;
}
