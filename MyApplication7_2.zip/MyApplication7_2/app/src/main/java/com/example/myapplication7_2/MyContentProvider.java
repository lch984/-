package com.example.myapplication7_2;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class MyContentProvider extends ContentProvider {

    public static final int CONTACTS_DIR = 0;
    public static final int CONTACTS_ITEM = 1;
    private static UriMatcher uriMatcher;
    private MyDatabase myDatabase;
    static {
        uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        uriMatcher.addURI("com.example.app.provider", "contacts", CONTACTS_DIR);
        uriMatcher.addURI("com.example.app.provider ", "contacts/#", CONTACTS_ITEM);
    }

    @Override
    public boolean onCreate() {
        myDatabase = new MyDatabase(getContext(), "db.db", null, 1);
        if(myDatabase!=null){
            return true;
        }
        return false;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {
        SQLiteDatabase db = myDatabase.getReadableDatabase();
        Cursor cursor = null;
        switch (uriMatcher.match(uri)) {
            case CONTACTS_DIR:
                cursor = db.query("contacts",projection,selection,selectionArgs,null,null,sortOrder,null);
                break;
            case CONTACTS_ITEM:
                long id = ContentUris.parseId(uri);
                cursor = db.query("contacts",projection,"id = ?",new String[]{id+""},null,null,sortOrder,null);
                break;
            default:
                cursor = null;
                break;
        }
        return cursor;
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        switch (uriMatcher.match(uri)) {
            case CONTACTS_DIR:
                return "vnd.android.cursor.dir/vnd.com.example.app.provider.contacts";
            case CONTACTS_ITEM:
                return "vnd.android.cursor.item/vnd.com.example.app.provider.contacts";
            default:
                break;
        }
        return null;
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues values) {
        SQLiteDatabase db = myDatabase.getWritableDatabase();
        if(uriMatcher.match(uri) == CONTACTS_DIR){
            db.insert("contacts",null,values);
            return uri;
        }
        return null;
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {
        SQLiteDatabase db = myDatabase.getWritableDatabase();
        int i = db.delete("contacts",selection,selectionArgs);
        return i;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues values, @Nullable String selection, @Nullable String[] selectionArgs) {
        SQLiteDatabase db = myDatabase.getWritableDatabase();
        int i = db.update("contacts", values, selection, selectionArgs);
        return i;
    }
}
