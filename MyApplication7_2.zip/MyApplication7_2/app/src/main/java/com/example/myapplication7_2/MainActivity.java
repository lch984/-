package com.example.myapplication7_2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ContentResolver cr = getContentResolver();
        Cursor cursor = cr.query(Uri.parse("content://com.example.app.provider/contacts"),null,null,null,null);
        while(cursor.moveToNext()){
            String name = cursor.getString(1);
            String money = cursor.getString(2);
            System.out.println(name + ";" + money);
        }
    }
}
