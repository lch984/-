package com.example.myapplication7_2;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class MyDatabase extends SQLiteOpenHelper {
    public static final String CREATE_CONTACTS = "create table contacts ("
            + "id integer primary key autoincrement, "
            + "name text , "
            + "number text, "
            + "sex text)";

    private Context mContext;

    public MyDatabase(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
        mContext = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_CONTACTS);
        Toast.makeText(mContext, "Create succeeded",
                Toast.LENGTH_SHORT).show();
        ContentValues values = new ContentValues();
        values.put("name","张三");
        values.put("number","13411453001");
        values.put("sex","男");
        db.insert("contacts", null, values); // 插入第一条数据
        values.clear();

        values.put("name","李妞");
        values.put("number","13411653002");
        values.put("sex","女");
        db.insert("contacts", null, values); // 插入第一条数据
        values.clear();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
